import { Component } from '@angular/core';
import {WeatherServiceService} from "./weather-service.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [WeatherServiceService]
})
export class AppComponent {
  constructor(private WeatherServiceService: WeatherServiceService) {

    
    this.WeatherServiceService.getTemperatureMock().then(tempdata => this.tempdata = tempdata);

   }

   tempdata: any[] = [];
  title = 'Weather Application @angular by Shruthi!';

 name: string = '';
}
