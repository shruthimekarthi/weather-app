import { Injectable } from '@angular/core';

@Injectable()
export class WeatherServiceService {

  mockData: any = [
  {name: "London", temperature: 36},
  {name: "Delhi", temperature: 41},
  {name: "Dubai", temperature: 38},
  {name: "Paris", temperature: 21}
];

getTemperatureMock()  {

return Promise.resolve(this.mockData);

}
}
